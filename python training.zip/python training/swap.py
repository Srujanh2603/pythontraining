a=4
b=5
print(a)
print(b)
temp=a
a=b
b=temp
print(a)
print(b)

'''def swap(a,b):
        print(BS)
        Print(a)
        print(b)
        t=a
        a=b
        b=a
        print(AS)
        print(a,b)'''

#Without 3rd variable
a=a+b
b=a-b
a=a-b

print(a)
print(b)