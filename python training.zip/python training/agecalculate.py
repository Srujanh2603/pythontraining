#Read name and year of the person and calculate his age in 2024
name=input("Enter name: ")
yob=int(input("Enter yob: "))
age=2024-yob
print("The person "+name+ "born in ",yob," is ",age," years old")