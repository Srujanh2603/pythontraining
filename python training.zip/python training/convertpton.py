#convert a no from negative to positive
num=int(input("Enter number: "))
print(num)
if num<0:
    p=abs(num)
    print(p)